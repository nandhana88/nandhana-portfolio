import { motion } from "framer-motion";
import {
  FaJava,
  FaPython,
  FaHtml5,
  FaCss3Alt,
  FaReact,
  FaNodeJs,
  FaGitAlt,
  FaGithub,
  FaFigma,
} from "react-icons/fa";

import {
  SiExpress,
  SiMongodb,
  SiCanva,
  SiJavascript,
} from "react-icons/si";

function Skills() {

  const skills = [
    { name: "Java", icon: <FaJava />, color: "text-orange-500" },
    { name: "Python", icon: <FaPython />, color: "text-yellow-400" },
    { name: "HTML", icon: <FaHtml5 />, color: "text-red-500" },
    { name: "CSS", icon: <FaCss3Alt />, color: "text-blue-500" },
    { name: "JavaScript", icon: <SiJavascript />, color: "text-yellow-300" },
    { name: "React", icon: <FaReact />, color: "text-cyan-400" },
    { name: "Node.js", icon: <FaNodeJs />, color: "text-green-500" },
    { name: "Express", icon: <SiExpress />, color: "text-gray-300" },
    { name: "MongoDB", icon: <SiMongodb />, color: "text-green-400" },
    { name: "Git", icon: <FaGitAlt />, color: "text-orange-600" },
    { name: "GitHub", icon: <FaGithub />, color: "text-white" },
    { name: "Figma", icon: <FaFigma />, color: "text-pink-500" },
    { name: "Canva", icon: <SiCanva />, color: "text-cyan-500" },
  ];

  return (

    <section
      id="skills"
      className="min-h-screen bg-[#020617] py-24 px-8"
    >

      <div className="max-w-7xl mx-auto">

        <motion.h2
          initial={{opacity:0,y:30}}
          whileInView={{opacity:1,y:0}}
          transition={{duration:.8}}
          className="text-5xl font-bold text-center mb-5"
        >
          Skills
        </motion.h2>

        <p className="text-center text-gray-400 mb-16 text-lg">
          Technologies and tools I use to build applications.
        </p>

        <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">

          {skills.map((skill,index)=>(

            <motion.div
              key={index}
              whileHover={{scale:1.08}}
              transition={{duration:.3}}
              className="bg-slate-900 border border-slate-800 rounded-3xl p-8 text-center hover:border-blue-500 hover:shadow-xl hover:shadow-blue-500/20 transition"
            >

              <div className={`text-6xl flex justify-center mb-5 ${skill.color}`}>
                {skill.icon}
              </div>

              <h2 className="text-2xl font-semibold">
                {skill.name}
              </h2>

            </motion.div>

          ))}

        </div>

      </div>

    </section>

  );
}

export default Skills;