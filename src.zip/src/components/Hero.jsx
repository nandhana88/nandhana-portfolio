import { TypeAnimation } from "react-type-animation";
import { FaGithub, FaLinkedin, FaEnvelope } from "react-icons/fa";
import profile from "../assets/profile.png";

function Hero() {
  return (
    <section
      id="home"
      className="min-h-screen flex items-center justify-center px-8"
    >
      <div className="max-w-7xl w-full grid md:grid-cols-2 gap-10 items-center">

        {/* Left Side */}
        <div>

          <p className="text-blue-400 text-xl mb-3">
            Hello, I'm
          </p>

          <h1 className="text-6xl font-extrabold mb-4">
            Nandhana A K
          </h1>

          <TypeAnimation
            sequence={[
              "Software Developer",
              2000,
              "Java Developer",
              2000,
              "Machine Learning Enthusiast",
              2000,
              "UI/UX Designer",
              2000,
            ]}
            speed={50}
            repeat={Infinity}
            className="text-2xl text-blue-400 font-semibold"
          />

          <p className="text-gray-400 mt-6 leading-8 max-w-xl">
            Passionate Computer Science Engineering student building
            innovative software solutions, exploring Artificial Intelligence,
            and designing intuitive digital experiences.
          </p>

          <div className="mt-8 flex gap-4">
            <button className="bg-blue-600 px-6 py-3 rounded-full hover:bg-blue-700 transition">
              Download Resume
            </button>

            <button className="border border-blue-500 px-6 py-3 rounded-full hover:bg-blue-500 transition">
              Contact Me
            </button>
          </div>

          <div className="flex gap-6 mt-8 text-3xl">
            <FaGithub className="cursor-pointer hover:text-blue-400 transition" />
            <FaLinkedin className="cursor-pointer hover:text-blue-400 transition" />
            <FaEnvelope className="cursor-pointer hover:text-blue-400 transition" />
          </div>

        </div>

        {/* Right Side */}
        <div className="flex justify-center">

          <div className="w-80 h-80 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 p-2">

            <img
              src={profile}
              alt="Profile"
              className="rounded-full w-full h-full object-cover"
            />

          </div>

        </div>

      </div>
    </section>
  );
}

export default Hero;