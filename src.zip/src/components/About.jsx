import { motion } from "framer-motion";
import {
  FaUserGraduate,
  FaLaptopCode,
  FaProjectDiagram,
  FaCertificate,
} from "react-icons/fa";

function About() {
  const cards = [
    {
      icon: <FaUserGraduate size={35} />,
      title: "CGPA",
      value: "8.0",
    },
    {
      icon: <FaProjectDiagram size={35} />,
      title: "Projects",
      value: "4+",
    },
    {
      icon: <FaLaptopCode size={35} />,
      title: "Internships",
      value: "2",
    },
    {
      icon: <FaCertificate size={35} />,
      title: "Certificates",
      value: "2+",
    },
  ];

  return (
    <section
      id="about"
      className="min-h-screen bg-slate-950 flex items-center py-24 px-8"
    >
      <div className="max-w-7xl mx-auto">

        <motion.h2
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: .8 }}
          className="text-5xl font-bold text-center mb-6"
        >
          About Me
        </motion.h2>

        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ delay: .2 }}
          className="text-gray-400 text-center max-w-4xl mx-auto leading-8 text-lg"
        >
          I am a Computer Science Engineering student passionate about
          software development, Artificial Intelligence, UI/UX Design,
          and solving real-world problems. I enjoy learning modern
          technologies and building applications that create meaningful
          impact.
        </motion.p>

        <div className="grid md:grid-cols-2 gap-16 mt-16">

          {/* Left */}
          <motion.div
            initial={{ x: -80, opacity: 0 }}
            whileInView={{ x: 0, opacity: 1 }}
            transition={{ duration: .8 }}
          >
            <h3 className="text-3xl font-bold mb-6 text-blue-400">
              My Journey
            </h3>

            <div className="border-l-4 border-blue-500 pl-6 space-y-10">

              <div>
                <h4 className="font-bold text-xl">
                  🎓 B.E Computer Science Engineering
                </h4>

                <p className="text-gray-400">
                  Nandha Engineering College
                </p>

                <span className="text-blue-400">
                  2023 - 2027
                </span>
              </div>

              <div>
                <h4 className="font-bold text-xl">
                  💻 Software Development
                </h4>

                <p className="text-gray-400">
                  Java • Python • Web Development
                </p>
              </div>

              <div>
                <h4 className="font-bold text-xl">
                  🤖 AI & Machine Learning
                </h4>

                <p className="text-gray-400">
                  Deep Learning • Computer Vision
                </p>
              </div>

            </div>

          </motion.div>

          {/* Right */}

          <motion.div
            initial={{ x: 80, opacity: 0 }}
            whileInView={{ x: 0, opacity: 1 }}
            transition={{ duration: .8 }}
            className="grid grid-cols-2 gap-6"
          >

            {cards.map((card) => (

              <div
                key={card.title}
                className="bg-slate-900 rounded-3xl p-8 text-center border border-slate-800 hover:border-blue-500 transition duration-300"
              >

                <div className="flex justify-center text-blue-500 mb-5">
                  {card.icon}
                </div>

                <h2 className="text-4xl font-bold">
                  {card.value}
                </h2>

                <p className="text-gray-400 mt-2">
                  {card.title}
                </p>

              </div>

            ))}

          </motion.div>

        </div>

      </div>
    </section>
  );
}

export default About;