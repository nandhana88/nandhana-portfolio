import { motion } from "framer-motion";
import { FaGithub, FaExternalLinkAlt } from "react-icons/fa";

function Projects() {
  const projects = [
    {
      title: "Venba Poultry Farms",
      description:
        "Designed an intuitive poultry farm management application with feed tracking, vaccination scheduling, stock management, and sales monitoring.",
      tech: ["Figma", "UI/UX"],
    },
    {
      title: "Traffic Violation Detection",
      description:
        "Built a deep learning system to detect helmet violations, red-light jumping, and mobile phone usage in real time.",
      tech: ["Python", "Deep Learning"],
    },
    {
      title: "Civik-Link",
      description:
        "Developed a road hazard reporting platform where users can submit image-based complaints for quicker issue resolution.",
      tech: ["HTML", "CSS", "JavaScript"],
    },
    {
      title: "Hotel Management System",
      description:
        "Created a responsive hotel booking and guest management website using HTML, CSS, and JavaScript.",
      tech: ["HTML", "CSS", "JavaScript"],
    },
  ];

  return (
    <section
      id="projects"
      className="min-h-screen bg-[#0F172A] py-24 px-8 text-white"
    >
      <div className="max-w-7xl mx-auto">

        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-5xl font-bold text-center mb-5"
        >
          Featured Projects
        </motion.h2>

        <p className="text-center text-gray-400 mb-16 text-lg">
          A few projects that reflect my learning and passion for software
          development.
        </p>

        <div className="grid md:grid-cols-2 gap-10">

          {projects.map((project, index) => (
            <motion.div
              key={index}
              whileHover={{ scale: 1.03 }}
              className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-lg hover:border-blue-500 transition"
            >

              {/* Placeholder Image */}
              <div className="h-56 bg-gradient-to-r from-blue-600 to-purple-600 flex items-center justify-center">
                <h2 className="text-3xl font-bold">
                  {project.title}
                </h2>
              </div>

              <div className="p-8">

                <p className="text-gray-400 leading-7">
                  {project.description}
                </p>

                <div className="flex flex-wrap gap-3 mt-6">
                  {project.tech.map((tech, i) => (
                    <span
                      key={i}
                      className="bg-blue-600 px-4 py-2 rounded-full text-sm"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

                <div className="flex gap-5 mt-8">

                  <button className="flex items-center gap-2 bg-blue-600 px-5 py-3 rounded-xl hover:bg-blue-700 transition">
                    <FaGithub />
                    GitHub
                  </button>

                  <button className="flex items-center gap-2 border border-blue-500 px-5 py-3 rounded-xl hover:bg-blue-600 transition">
                    <FaExternalLinkAlt />
                    Live Demo
                  </button>

                </div>

              </div>

            </motion.div>
          ))}

        </div>

      </div>
    </section>
  );
}

export default Projects;